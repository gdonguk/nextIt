package godonguk.submit_07;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Submit07 {

	public static void main(String[] args) {
		System.out.println("\n=====================1번============\n");

		int idx = 0;
		ArrayList<Integer> rando = new ArrayList<>();
		ArrayList<Integer> rando2 = new ArrayList<>();
		System.out.print("랜덤숫자: ");
		for (int i = 0; i < 10; i++) {
			idx = (int) (Math.random() * (20 - 10 + 1)) + 10;
			rando.add(idx);
			System.out.print(rando.get(i) + " ");
		}
		System.out.println();
		System.out.println(rando);
//		for (int i = 0; i < 10; i++) {
//			if (rando.get(i) != rando.get(i)) {
//				idx = rando.get(i);
//			}
//		}
//		System.out.println(rando2);

		System.out.println("\n=====================2번============\n");

		
		
		ArrayList<String> aList = new ArrayList<String>(Arrays.asList("냉장고", "로봇청소기", "세탁기", "에어컨"));
		ArrayList<String> bList = new ArrayList<String>(Arrays.asList("노트북", "TV", "에어컨", "플레이스테이션", "로봇청소기"));
		ArrayList<String> cList = new ArrayList<>();
		for(int i = 0; i < aList.size(); i ++ ) {
			for(int j = 0; j < bList.size(); j ++ ) {
				if(aList.get(i) == bList.get(j)) {
					cList.add(bList.get(j));
				}
			}
		}
		System.out.println("1번" +cList);
		
		
		
		
		
	} // main끝

//	public static int makeRandom(int a, int b){
//		int[] result = new int[10];
//		int idx = 0;
//	
//		outer: while(true) {
//			int rand = (int)(Math.random() * (b-a+1)) + a;
//			for(int i = 0; i < result.length; i++) {
//				if(result[i] == rand) {
//					continue outer;
//				}
//			}
//			result[idx] = rand;
//			idx++;
//			if(idx == 10) {
//				break;
//			}
//		}
//		
//		for(int i = 0; i < result.length; i++) {
//			System.out.print(result[i] + " ");
//		}
//		Arrays.sort(result);
//		
//		return idx;
//	}

}
