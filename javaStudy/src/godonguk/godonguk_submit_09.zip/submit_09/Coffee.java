package godonguk.submit_09;

public class Coffee {
	String name;
	int price;
	
}
