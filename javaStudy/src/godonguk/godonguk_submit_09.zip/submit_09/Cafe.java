package godonguk.submit_09;

public class Cafe {
	

}
